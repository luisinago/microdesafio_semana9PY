from setuptools import setup

setup(
    name= "Microdesafío - Semana 9",
    version= "1.0",
    author= "LuisinaGonzalez",
    description= "Nada",
    author_email= "luisinago@gmail.com",
    packages=["paquete"])